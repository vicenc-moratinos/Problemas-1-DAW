import fecha.*;

public class Main {

    public static void main (String[]args) {

        System.out.println("");
        Fecha data = new Fecha(EnumMes.Enero);
    }
}