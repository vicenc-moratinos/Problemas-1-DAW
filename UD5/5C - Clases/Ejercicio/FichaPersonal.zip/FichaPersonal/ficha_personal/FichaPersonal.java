import Ejercicio.Fecha.fecha.*;
package ficha_personal;

public class FichaPersonal {

    private Fecha fechaActual = new Fecha(6,EnumMes.Febrero, 2026);
    private String nombre = "";
    private Fecha nacimiento = new Fecha();
    private int edad = 0;

    public FichaPersonal (String nombre, Fecha nacimiento, int edad) {
        this.nombre = nombre;
        this.nacimiento = nacimiento;
        this.edad = edad;
    }

    public FichaPersonal (String nombre, Fecha nacimiento) {
        this.nombre = nombre;
        this.nacimiento = nacimiento;
        this.edad = nacimiento.anio - fechaActual.anio;
    }

    public FichaPersonal (int edad) {
        this.edad = edad;
    }

    public FichaPersonal (String nombre) {
        this.nombre = nombre;
    }
    
    public FichaPersonal (Fecha nacimiento) {
        this.nacimiento = nacimiento;
    }

    public void toString() {
        System.out.println("Nombre: " + nombre );
        System.out.println("Nacimiento " + fecha.toString());
        System.out.println("Edad: " +  edad);
    }
}