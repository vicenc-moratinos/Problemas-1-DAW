/*Desarrollar un programa en Java que implemente un cifrado simple donde cada letra de una frase se
desplace un número fijo de posiciones en el alfabeto (un cifrado César con desplazamiento 3).
A -> D, B -> E, etc.
Ej: "Java" → "Mdyd"*/

import java.util.Arrays;
import java.util.Scanner;

public class Arrays13_1 {
    public static void main (String[]args) {

        //declaramos variables y obj scanner
        Scanner sc = new Scanner(System.in);
        String frase = "";

        //pedimos frase y creamos un array a partir del string
        System.out.print("Introduce una frase: ");
        frase = sc.nextLine();
        char[] fraseArray = frase.toCharArray();

        //bucle for donde se suma 3 al caracter asci, o resta 23 para xyz y se respetan los espacios
        for (int i = 0; i < fraseArray.length; i++) {

            if (fraseArray[i] == ' ') {
               System.out.print(fraseArray[i]);
            }
            else if ((fraseArray[i] <= 'z' && fraseArray[i] >= 'x' ) || (fraseArray[i] <= 'Z' && fraseArray[i] >= 'X' )) {
                fraseArray[i] = (char)(fraseArray[i] - 23);
                System.out.print(fraseArray[i]);
            }
            else {
                fraseArray[i] = (char)(fraseArray[i] + 3);
                System.out.print(fraseArray[i]);
            }
        }
        System.out.println("");
    }
}