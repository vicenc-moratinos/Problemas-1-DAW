import java.util.Scanner;

public class Cadenas6Repaso {

    public static void main (String[]args) {

        Scanner sc = new Scanner(System.in);
        String cad;
        String cad2;
        boolean contiene;

        System.out.println("CAd1");
        cad = sc.nextLine();
        System.out.println("CAd2");
        cad2 = sc.nextLine();

        contiene = cad.contains(cad2);
        System.out.println(contiene);
        if (contiene)
        {
            System.out.println("La cadena contenida empieza en " + (cad.indexOf(cad2)));
        }
    }
}