import java.util.Arrays;
import java.util.Scanner;

public class Arrays9 {

    public static void main (String[]args) {
        
        int numero = 0;
        String frase = "";
        char letra = '_';
        Scanner sc = new Scanner(System.in);
        char [] abcdario = new char[] {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h',
                                 'i', 'j', 'k', 'l', 'm', 'n', 'o','p', 'q',
                             'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
        int [] recuentoAbcdario = new int[26];
        
        System.out.println("Introduce una frase");
        frase = sc.nextLine().toLowerCase();
        
        for (int i = 0 ; i < frase.length() ; i++) {
            letra = frase.charAt(i);
            numero = Character.getNumericValue(letra) - 10;
            System.out.println(numero);
            
            if (numero >= 0 && numero <= 25) {
                recuentoAbcdario[(numero)] += 1;
                //System.out.println(numero);
            }
        }
        
        System.out.println("Numero de veces que aparece cada letra");

        System.out.println(Arrays.toString(abcdario));
        System.out.println(Arrays.toString(recuentoAbcdario));
    }
}