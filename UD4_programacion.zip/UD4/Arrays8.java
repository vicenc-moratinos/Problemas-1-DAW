import java.util.Arrays;

public class Arrays8 {
    public static void main (String[]args) {

        int [] array = new int[20];
        int [] arrayOrdenado = new int[20];
        int posicion = 0;
        int posicionDescendiente = array.length -1 ;
        

        System.out.println("Orden inicial:");

        for (int i = 0; i < array.length; i++) {
            array[i] = (int)(Math.random()*(101));
        }
        
        System.out.println(Arrays.toString(array));

        System.out.println("Posicion cambiada");

        for (int i = 0 ; i < array.length ; i++) {
            if (array[i] % 2 == 0) {
                arrayOrdenado[posicion] = array[i];
                posicion++;
            }
            else {
                arrayOrdenado[posicionDescendiente] = array[i];
                posicionDescendiente--;
            }
        }

        System.out.println(Arrays.toString(arrayOrdenado));

    }
}