/*Crea un array e inicializalo con los siguientes valores {2, 5, 9, -4, 6}. Ordena el array y muéstralo
por pantalla usando métodos de la clase Arrays.*/

import java.util.Arrays;

public class Arrays12 {
    public static void main (String[]args) {

        int array [] = new int[] {2,5,9,-4,6};

        Arrays.sort(array);
        System.out.println(Arrays.toString(array));

    }
}