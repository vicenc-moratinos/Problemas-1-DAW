import java.util.Scanner;
import java.util.Arrays;

public class Array10 {

    public static void main (String[]args) {

        Scanner sc = new Scanner(System.in);
        String [] cadenas = new String[10];
        StringBuilder cadenaCompleta = new StringBuilder();

        
        for (int i = 0 ; i < cadenas.length ; i++) {

            System.out.print("\nIntroduce la cadena " + i +": ");
            cadenas[i] = sc.nextLine();
            cadenaCompleta = cadenaCompleta.append(cadenas[i]);
        }
        System.out.println(cadenaCompleta);
    }
}

