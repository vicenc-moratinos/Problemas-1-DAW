/*Utilizando un array de cadenas de caracteres para almacenar colores {rojo, amarillo, verde, blanco,
azul, negro}, implementa un programa que genera una bandera de colores aleatorios. Por ejemplo, si
el usuario quiere una bandera de dos franjas, una posible salida sería "blanco" y "rojo".*/

import java.util.Arrays;
import java.util.Scanner;

public class Arrays11 {
    public static void main (String[]args) {

        Scanner sc = new Scanner(System.in);
        String [] colores = new String[] {"rojo","amarillo","verde","blanco","azul","negro"};
        int cantColores = 0;
        int random = 0;
        


        System.out.print("Introduce la cantidad de colores que quieres en tu bandera: ");
        cantColores = sc.nextInt();

        System.out.print("Tu bandera tiene ");

        for (int i = 1 ; i <= cantColores ; i++) {
            
            random = (int)(Math.random()*((5)+1));
            System.out.print(colores[random]);

            if (i < cantColores)
                System.out.print(" y ");
        }
        System.out.println("");
    }
}