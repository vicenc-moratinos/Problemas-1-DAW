import java.util.Arrays;
import java.util.Scanner;

public class Arrays9_1 {

    public static void main (String[]args) {
        
        int numero = 0;
        String frase = "";
        char letra = '_';
        Scanner sc = new Scanner(System.in);
        int [] recuentoAbcdario = new int[26];
        
        System.out.println("Introduce una frase");
        frase = sc.nextLine().toLowerCase();
        
        for (int i = 0 ; i < frase.length() ; i++) {
            letra = frase.charAt(i);
            numero = Character.getNumericValue(letra) - 10;
            
            if (numero >= 0 && numero <= 25) {
                recuentoAbcdario[(numero)] += 1;
                //System.out.println(numero);
            }
        }
        
        System.out.println("Numero de veces que aparece cada letra");

        for (int i = 0 ; i < recuentoAbcdario.length ; i++) {    
            letra = (char)((i)+'a');
            System.out.print(letra + ": " + recuentoAbcdario[i] + ", ");            
        }
        System.out.println("");
    }
}