public class Arrays1 {

    public static void main (String[]args) {

        char arrayDeNumeros [] = new char [11]; 

        arrayDeNumeros [0] = 'p';
        arrayDeNumeros [1] = 'a';
        arrayDeNumeros [4] = 'b';
        arrayDeNumeros [6] = 'd';
        arrayDeNumeros [8] = 'h';
        arrayDeNumeros [9] = 'l';
       
        for (int i = 0; i < arrayDeNumeros.length; i++) {
            System.out.println("numero " + i + " del array : "+ arrayDeNumeros [i]);
        }
    }
}