/*Utilizando un array de cadenas de caracteres para almacenar colores {rojo, amarillo, verde, blanco,
azul, negro}, implementa un programa que genera una bandera de colores aleatorios. Por ejemplo, si
el usuario quiere una bandera de dos franjas, una posible salida sería "blanco" y "rojo".*/

import java.util.Arrays;
import java.util.Scanner;

public class Arrays11_1 {
    public static void main (String[]args) {

        Scanner sc = new Scanner(System.in);
        String [] colores = new String[] {"rojo","amarillo","verde","blanco","azul","negro"};
        int cantColores = 0;
        int coloresQueYaHanSalido [] = new int [] {-1,-1,-1,-1,-1,-1};
        int random = 0;
        boolean colorYaSalio = false;
        


        System.out.print("Introduce la cantidad franjas que quieres en tu bandera  (1-6): ");
        cantColores = sc.nextInt();


        if (cantColores > 6 || cantColores <= 0){
            System.out.println("Introduce una cantidad válida");
        }
        else {

            System.out.print("Tu bandera tiene franjas de color ");

            for (int i = 1 ; i <= cantColores ; i++) {
                
                do {
                    if (i == 1){
                        random = (int)(Math.random()*((6)));
                        coloresQueYaHanSalido [i-1] = random;
                    }

                    else {

                        for (int j = 0 ; j < coloresQueYaHanSalido.length ; j++ ) {
                            System.out.println(coloresQueYaHanSalido[j]);
                            coloresQueYaHanSalido [i-1] = random;
                            if (random == coloresQueYaHanSalido [j]) {
                                colorYaSalio = true;
                                random = (int)(Math.random()*((6)));
                                
                            }
                            else{
                                coloresQueYaHanSalido [i-1] = random;
                                
                            }
                        }
                    }
                    System.out.print(colores[random]);
                } while (colorYaSalio || i == coloresQueYaHanSalido.length);
                


                if (i < cantColores)
                    System.out.print(" y ");
            }
        }
                System.out.println(Arrays.toString(coloresQueYaHanSalido));    
        System.out.println("");
    }
}