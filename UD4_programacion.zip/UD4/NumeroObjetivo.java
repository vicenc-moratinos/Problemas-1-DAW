/*Dado un array y un número objetivo, encuentra dos posiciones cuya suma sea el objetivo.*/

import java.util.Arrays;
import java.util.Scanner;

public class NumeroObjetivo {
    public static void main (String[]args) {

        //declaramos variables y obj scanner
        Scanner sc = new Scanner(System.in);
        int numeroObjetivo = 0;
        int [] arrayDeNumeros = new int[30];
        boolean noHaySuma = true;

        System.out.println("**************************");
        System.out.println("Dado el siguiente array: ");

        for (int i = 0; i < arrayDeNumeros.length; i++){
            arrayDeNumeros[i] = (int)(Math.random()*(101));
        }
        System.out.println(Arrays.toString(arrayDeNumeros));
        System.out.println("**************************");
        System.out.print("Introduce el x (2 - 199)para encontrar dos elementos de un array aleatorio que sumen x: ");
        numeroObjetivo = sc.nextInt();

        for (int i = 0; i < arrayDeNumeros.length; i++) {
            for(int j = i + 1; j < arrayDeNumeros.length; j++ ) {
                if (arrayDeNumeros[i] + arrayDeNumeros[j] == numeroObjetivo) {
                    System.out.println("Posicion "+ i + " = " + arrayDeNumeros[i]);
                    System.out.println("Posicion "+ j + " = " + arrayDeNumeros[j]);
                    System.out.println(arrayDeNumeros[i]+" y "+arrayDeNumeros[j] +" es igual a " + numeroObjetivo);
                    noHaySuma = false;
                }
                
            }
        }
        if (noHaySuma) {
            System.out.println("No hay dos numeros que sumen "+ numeroObjetivo);
        }
    }
}