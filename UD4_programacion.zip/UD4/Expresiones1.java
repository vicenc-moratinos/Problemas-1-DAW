import java.util.Scanner;
import java.util.regex.*;

public class Expresiones1 {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        String dni = "";
        

        System.out.print("Introduce tu DNI '12345678X': ");
        dni = sc.nextLine().toUpperCase();

        Pattern regExDni = Pattern.compile("^[\\d]{8}[a-zA-Z]$");
        Matcher comprobacionRegexDni = regExDni.matcher(dni);

        if (comprobacionRegexDni.matches()) 
            System.out.println("yeeey");
        

    }  
}
