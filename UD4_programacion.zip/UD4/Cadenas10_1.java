import java.util.Scanner;

public class Cadenas10_1 {

    public static void main (String[]args){
        
        Scanner sc = new Scanner(System.in);
        String cad1 = "";
        String opcion;
        String a = "a";
        String cadenaInvertida = "";
        String [] cadArray;
        int longitudCadena = 0;
        int contadorPalabras = 0;
        int contadorA = 0;
        int i = 0;
        char letra = '_';
        char ultimaLetra = '_';
        StringBuilder = strb;
        

        do 
        { 
            System.out.println("introduce una cadena");
            cad1 = sc.nextLine();
            System.out.println("\nintroduce la opción deseada");
            System.out.println("\na) Contar el numero de letras que tiene\nb) Contar el numero de palabras\nc) Contar el numero de a\nd) Presentarla en consola invertida palabra a palabra\ne) Presentarla en consola invertida letra a letra\nescribe s para salir");
            opcion = sc.nextLine();
            
            System.out.println("\n******************************");
            
            opcion = opcion.toLowerCase();
            longitudCadena = cad1.length();

            //a)
            if (opcion.equals("a"))
            {
                
                System.out.println("La cadena \""+cad1+"\" tiene una longitud de: " + longitudCadena);
            }

            //b)
            else if (opcion.equals("b"))
            {
                for(i = 0; i < longitudCadena; i++)
                {
                    letra = cad1.charAt(i);

                    if (ultimaLetra == ' ' || i == 0)
                    {
                        contadorPalabras++;
                    }
                    ultimaLetra = letra;
                    
                }
                System.out.println("La cadena contiene "+contadorPalabras+" palabras");
            }

            else if (opcion.equals("c"))
            {
                for(i = 0; i < longitudCadena; i++)
                {
                    letra = cad1.charAt(i);
                    if (letra == 'a' || letra == 'A')
                    {
                        contadorA++;  
                    }
                }
            }
            if (opcion.equals("c"))
            {
            System.out.println("La cadena contiene "+contadorA+" letras A");
            }

            //d)
            else if (opcion.equals("d"))
            {
                cadArray = cad1.split(" "); 

                for (i = (cadArray.length - 1); i >= 0; i--) 
                {
                    System.out.print(cadArray[i] + " ");
                }
                System.out.println();
            }
            

            //e
            else if (opcion.equals("e"))
            {
                for (i = longitudCadena -1 ; i>=0; i--)
                {
                    
                    letra = cad1.charAt(i);
                    cadenaInvertida += letra;

                    ultimaLetra = letra;
                }
                
                System.out.println("cadena invertida: "+cadenaInvertida);
            }

            else if (!opcion.equals("s"))
            {
                System.out.println("Introdce una de las opciones posible cazurro");
            }
            System.out.println("******************************");
        }
        while (!opcion.equals("s"));
    }
}