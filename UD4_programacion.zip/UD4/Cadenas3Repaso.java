import java.util.Scanner;

public class Cadenas3Repaso {

    public static void main (String[]args) {

        Scanner sc = new Scanner(System.in);
        String cad;

        System.out.println("Introduce una cadena");
        cad = sc.nextLine();

        if (cad.equals(""))
        {
            System.out.println("CAdena vacia");
        }
        else
        {
            System.out.println("Cadena llena");
            System.out.println(cad);
        }
    }
}