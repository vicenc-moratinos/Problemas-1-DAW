public class Primitivos {

    public static void main(String[]args){

        int numero = 9;
        int numero2 = 7;
        
        float numeroConComillas = 1.7F;
        boolean verdadero = true;
        char letra = 'a';
        String frase = "";

        if (numero < 10)
        {
            System.out.println(numero + " es mas pequeño que 10");
        }
        else if (numero > 10)
        {
           System.out.println(numero + "es mayor que 10"); 
        }
        else 
        {
            System.out.println(numero+ " es igual a 10");
        }
    }
} 