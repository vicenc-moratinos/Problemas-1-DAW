import java.util.Scanner;

public class Arrays2 {

    public static void main (String[]args) {

        Scanner sc = new Scanner(System.in);
        int arrayDeNumeros [] = new int [10];

        for (int i = 0; i < arrayDeNumeros.length; i++) {
            System.out.println("Introduce un numero en la posicion " + i);
            arrayDeNumeros[i] = sc.nextInt();
        }

        for (int i = arrayDeNumeros.length -1;i >= 0 ; i--) {
            System.out.println("Posicion de array " +i+ ": " + arrayDeNumeros[i]);
        }
    }
}