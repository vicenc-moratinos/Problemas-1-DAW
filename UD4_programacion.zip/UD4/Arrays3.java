public class Arrays3 {

    public static void main (String[]args) {

        int [] num = new int [20];
        int [] numSqrt = new int [20];
        int [] numCube = new int [20];

        for (int i = 0; i < num.length ; i++) {
            num[i] = (int)(Math.random()*(100+1));
        }
        for (int i = 0; i < num.length ; i++) {
            numSqrt[i] = num[i]*num[i];
        }
        for (int i = 0; i < num.length ; i++) {
            numCube[i] = num[i]*num[i]*num[i];
        }
        System.out.println("___________________________");
        System.out.println("|Numero |Cuadrado|Cubo    |");
        System.out.println("|_________________________|");

        for (int i = 0; i < num.length ; i++){
            System.out.printf("\n|%7d|%8d|%8d|",num[i],numSqrt[i],numCube[i]);
           // System.out.println("");
        }
        System.out.println("");
    }
}