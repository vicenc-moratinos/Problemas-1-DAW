import java.util.Scanner;

public class Cadenas7 {

    public static void main (String[]args){

        Scanner sc = new Scanner(System.in);
        String cad1, concat="";
        int longitud,i=0;
        char ultimaLetra = 'a';
        boolean comprobacion = false;
        
        Character espacio = ' ', letra;
        System.out.println("Introduce cadena1");
        cad1 = sc.nextLine().toLowerCase();
        
        longitud = cad1.length();

        for (i = 0; i<longitud; i++ )
        {
            letra = cad1.charAt(i);

            if (i == 0 || comprobacion)
            {
                concat +=  Character.toUpperCase(letra);
            }
            else
            {
                concat += letra;
            }
            comprobacion = letra.equals(espacio);
            ultimaLetra = letra;
        }
        System.out.println(concat);
        
    }
}