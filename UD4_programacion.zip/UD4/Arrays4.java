import java.util.Scanner;
public class Arrays4 {

    public static void main (String[]args) {

        Scanner sc = new Scanner(System.in);
        int [] array = new int [10];
        int numeroMaximo = 0;
        int numeroMinino = 0;

        for (int i = 0; i < array.length; i++) {
            System.out.println("Introduce el valor para la posicion "+i);
            array[i] = sc.nextInt();

            if (i == 0) {
                numeroMaximo = array[i];
                numeroMinino = array[i];
            }
            
            if(array[i]>numeroMaximo){
                numeroMaximo = array[i];
            }
            if (array[i]<numeroMinino){

                numeroMinino = array[i];
            }
        }

        
        for (int i = 0; i < array.length; i++) {
            if (array[i] == numeroMaximo) {
                System.out.printf("\nPosicion %d : %d mayor",i,array[i]);
            }

            else if (array[i] == numeroMinino) {
                System.out.printf("\nPosicion %d : %d menor",i,array[i]);
            }

            else {
                System.out.printf("\nPosicion %d : %d",i,array[i]);
            }
            System.out.println("");
        }
    }
}