import java.util.Scanner;

public class Cadenas5 {

    public static void main (String[]args){

        Scanner sc = new Scanner(System.in);
        String cad1, cad2 , intercambio;

        System.out.println("Introduce cadena1");
        cad1 = sc.nextLine();
        System.out.println("Introduce cadena2");
        cad2 = sc.nextLine();
        
        intercambio = cad1;
        cad1 = cad2;
        cad2 = intercambio;

        System.out.printf("\ncad1: %s cad2: %s",cad1,cad2);
    }
}