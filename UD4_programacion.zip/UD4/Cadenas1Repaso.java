import java.util.Scanner;

public class Cadenas1Repaso {

    public static void main (String[]args) {

        Scanner sc = new Scanner(System.in);
        String cad ="";
        String concat = "";
        char letra;
        int i = 0;
        int longitud;

        try {
            System.out.println("Introduce una cadena");
            cad = sc.nextLine();
        }
        catch (Exception e)
        {
            System.out.println("Ha habido una excepcion");
        }

        longitud = cad.length();
        System.out.println(longitud);

        for (i = 0; i < longitud; i++)
        {

            letra = cad.charAt(i);
            concat += letra;
            //System.out.println(letra);
            //System.out.println();

        }
        System.out.println(concat);
    }
}