import java.util.Scanner;

public class Cadenas4 {

    public static void main (String[]args){

        Scanner sc = new Scanner(System.in);
        String cad1, cad2 , cadConcat;

        System.out.println("Introduce cadena1");
        cad1 = sc.nextLine();
        System.out.println("Introduce cadena2");
        cad2 = sc.nextLine();
        
        cadConcat = cad1.concat(cad2);
        System.out.println(cadConcat);
    }
}