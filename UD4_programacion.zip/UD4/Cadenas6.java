import java.util.Scanner;

public class Cadenas6 {

    public static void main (String[]args){

        Scanner sc = new Scanner(System.in);
        String cad1, cad2 ;
        boolean contieneCadena;


        System.out.println("Introduce cadena1");
        cad1 = sc.nextLine();
        System.out.println("Introduce cadena para comprobar si hay una cadena contenida");
        cad2 = sc.nextLine();
        
        contieneCadena = cad1.contains(cad2);
        System.out.printf("\n%s esta contenida en %s: Por tanto es %b\n",cad2,cad1,contieneCadena);
    }
}