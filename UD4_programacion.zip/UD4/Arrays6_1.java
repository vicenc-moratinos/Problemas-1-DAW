import java.util.Scanner;
import java.util.Arrays;

public class Arrays6_1 {
    public static void main(String[] args) {
        int[] arrayDeNumeros = new int[100];
        Scanner sc = new Scanner(System.in);

        // Llenar el arreglo con números aleatorios entre 0 y 100
        for (int i = 0; i < arrayDeNumeros.length; i++) {
            arrayDeNumeros[i] = (int) (Math.random() * 101);
        }

        // Pedir los números al usuario
        System.out.println("Introduce el número a cambiar:");
        int numeroCambiar = sc.nextInt();
        System.out.println("Introduce el nuevo número:");
        int nuevoNumero = sc.nextInt();

        // Reemplazar los valores en el arreglo directamente
        for (int i = 0; i < arrayDeNumeros.length; i++) {
            if (arrayDeNumeros[i] == numeroCambiar) {
                arrayDeNumeros[i] = nuevoNumero;
            }
        }

        // Mostrar el arreglo actualizado
        System.out.println(Arrays.toString(arrayDeNumeros));
    }
}
