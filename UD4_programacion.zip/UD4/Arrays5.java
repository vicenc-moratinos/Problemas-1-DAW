import java.util.Scanner;
import java.util.Arrays;

public class Arrays5 {

    public static void main (String[]args) {

        Scanner sc = new Scanner(System.in);
        int [] arrayDeNumeros = new int [15];
        int variableIntercambio = 0;
        String cad = "";

        for (int i = 0;i < arrayDeNumeros.length;i++) {
            System.out.print("Introduce el numero del array en la posicion: " + i + " : \n");
            arrayDeNumeros[i] = sc.nextInt();
        }

        variableIntercambio = arrayDeNumeros[arrayDeNumeros.length-1];
        for (int i = arrayDeNumeros.length - 1 ;i >0;i--) {
                arrayDeNumeros[i] = arrayDeNumeros[i-1];
        }    
        
        arrayDeNumeros[0] = variableIntercambio;
        
        cad = Arrays.toString(arrayDeNumeros);
        System.out.println(cad);
        

    }
}