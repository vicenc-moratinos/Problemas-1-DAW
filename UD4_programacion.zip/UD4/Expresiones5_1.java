import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class Expresiones5_1 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String matricula = "";

        // Creamos el patrón solo una vez
        
        Matcher comprobacionRegex = null;
        Pattern patronRegex = Pattern.compile("^[0-9]{4}[A-Z&&[^AEIOUÑQ]]{3}$");

        //bucle del programa
        do {
            //pedimos la matricula
            System.out.println("Introduce tu matrícula:");
            matricula = sc.nextLine().toUpperCase();

            //Creamos el patron y el matcher
            comprobacionRegex = patronRegex.matcher(matricula);

           //condicional para comprobar si el formato es corPattern patronRegexrecto
            if (!comprobacionRegex.matches()) {
                System.out.print("el formato no es correcto\n");
            }
            else {
                System.out.println("Tu matrícula válida es: " + matricula);
            }
        } 
        while (!comprobacionRegex.matches());
    }
}
