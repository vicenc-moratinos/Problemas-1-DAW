public class StringBuilder1 {

    public static void main (String[]args) {

        StringBuilder strb = new StringBuilder("");
        int i;

        for (i = 0; i < strb.length(); i++)
        {
            strb.append(strb.charAt(0));
            strb.delete(0,1);
            System.out.println(strb);
        }
    }
}