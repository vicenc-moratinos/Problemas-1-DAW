import java.util.Scanner;

public class StringBuilder10 {

    public static void main (String[]args) {

        char opcion;
        String cadena = "Siempre se puede aprender Java";
        StringBuilder cadenaBuilder = new StringBuilder(cadena.trim());
        Scanner sc = new Scanner(System.in);
        int contadorPalabras = 0;
        int i = 0;
        char  ultimaLetra = '_';
        char  letra = '_';

        do
        {

            System.out.println("Introduce la opcionn que quieras a - e");
            opcion = sc.nextLine().toLowerCase().charAt(0);

            if (opcion == 'a')
            {
                
                System.out.println("La cadena tiene "+ cadena.replace(" ","").length());
            }

            else if (opcion == 'b')
            {
                for (i = 0; i < cadena.length(); i++)
                {
                    letra = cadena.charAt(i);
                    if (i == 0 || (ultimaLetra == ' ' && letra != ' '))
                    {
                    contadorPalabras++;
                    }

                ultimaLetra = letra;
                }
                System.out.println("numero de palabras: "+ contadorPalabras);
            }
            else if (opcion == 'c')
            {
                
            }
            else if (opcion == 'e')
            {
                
            }
            else if (opcion == 'e')
            {
                
            }
            else if (opcion == 's')
            {

            }
            else 
            {
                System.out.println("Opcion incorrecta");
            }
        } while (opcion !='s');

        

      
    }
}
