import java.util.Scanner;

public class Cadenas11 {

    public static void main (String []args) {

        Scanner sc = new Scanner(System.in);
        String [] colorArray = new String[5];
        String color;
        String posicion;
        int i = 0;
        int j = 0;
        int cuentaAtras = 4;
        int cuentaAdelante = 0;

        for (i = 0 ; i <= 4 ; i++)
        {
            do 
            {

            System.out.println("introduce un color");
            color = sc.nextLine();
            System.out.println("Introduce primero o ultimo");
            posicion = sc.nextLine();
            
            if (!posicion.equals("primero") && !posicion.equals("ultimo"))
                {
                    System.out.println("Introduce una poscion valida");
                }
            }
            while (!posicion.equals("primero") && !posicion.equals("ultimo"));
            
            if (posicion.equals("primero"))
            {
                colorArray[cuentaAdelante] = color;
                System.out.println("Guardado en la posicion "+cuentaAdelante +"\n");
                cuentaAdelante++;
            }
            else
            {
                colorArray[cuentaAtras] = color;
                System.out.println("Guardado en la posicion "+cuentaAtras +"\n");
                cuentaAtras--;
            }
        }

        for (j = 0 ; j <= 4 ; j++)
        {
            System.out.println("\nLa posicion " + (j) + " del array es; "+colorArray[j]);
        }

    }
}