import java.util.Scanner;

public class Expresiones5 {

    public static void main (String[]args) {

        Scanner sc = new Scanner(System.in);
        String matricula = "";

        do {
            System.out.println("Introduce tu matricula");
            matricula = sc.nextLine().toUpperCase();

            if (!matricula.matches("^[B-Z&&[^ÑQAEIOU]]{3}[0-9]{4}$")) {
                System.out.println("El formato no es correcto");
            }
            else {
               System.out.println("TU matricula válida es: " + matricula); 
            }
        }
        while (!matricula.matches("^[B-Z&&[^ÑQAEIOU]]{3}[0-9]{4}$"));
    }
}