

public class Cadenas9 {

    public static void main (String[]args){
        
        String cad1 = "Esto es una String";
        String cad2 = "Y esto También";
        String cad3="";
        String cad4="";

        System.out.println("Las cadenas son iguales? " + cad1.equals(cad2));

        cad3 = cad1.concat(cad2);
        System.out.println("Cadenas concatenadas " + cad3);

        cad4 = cad1.concat(cad2);
        System.out.println("Cadenas concatenadas " + cad4);

        System.out.println("Las cadenas son iguales? "+cad3.equals(cad4));

        System.out.println("String 1 tiene longitud de " + cad1.length());
        System.out.println("String 2 tiene longitud de " + cad2.length());

        cad1 = cad2;
        System.out.println("String 1: "+ cad1);

        cad1 =  cad1.replace("También","Además");
        System.out.println("Hacemos replace de cad1 de También por Además. Cad1: "+ cad1);

        System.out.println("String 1: "+ cad1);
        System.out.println("String 2: "+ cad2);


        
    }
}