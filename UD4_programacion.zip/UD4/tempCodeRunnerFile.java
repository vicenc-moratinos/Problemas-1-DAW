import java.util.Arrays;

public class Arrays8 {
    public static void main (String[]args) {
