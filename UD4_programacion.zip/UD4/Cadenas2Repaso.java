import java.util.Scanner;

public class Cadenas2Repaso {

    public static void main (String []args) {

        Scanner sc = new Scanner(System.in);
        int tlf;
        String nombre = "";
        String direccion = "";
        boolean bandera = false;

        do 
        {
            try 
            {   
                System.out.println("introducee nombre");
                nombre = sc.nextLine();
                System.out.println("introducee tlf");
                tlf = Integer.parseInt(sc.nextLine());
                System.out.println("introducee direccion");
                direccion = sc.nextLine();
                bandera = false;

            }
            catch (Exception e)
            {
                System.out.println("aaaa");
                bandera = true;
            }
        } while (bandera);
    }
}