/*Desarrollar un programa en Java que implemente un cifrado simple donde cada letra de una frase se
desplace un número fijo de posiciones en el alfabeto (un cifrado César con desplazamiento 3).
A -> D, B -> E, etc.
Ej: "Java" → "Mdyd"*/

import java.util.Arrays;
import java.util.Scanner;

public class Arrays13 {
    public static void main (String[]args) {

        Scanner sc = new Scanner(System.in);
        char [] abcdario = new char[] {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h',
                                 'i', 'j', 'k', 'l', 'm', 'n', 'o','p', 'q',
                             'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
        String frase = "";
        String fraseCripto = "";

        System.out.println("Introduce una frase para encriptar");
        frase = sc.nextLine().toLowerCase();

        for (int i = 0;  i < frase.length(); i++) {
            
            if (frase.charAt(i) == ' '){
                fraseCripto += " ";
            }
            for (int j = 0; j < abcdario.length; j++){
                if (frase.charAt(i) == abcdario[j]) {
                    if (j >= 23) {
                        fraseCripto += abcdario[j -23];
                    }
                    else {
                        fraseCripto += abcdario[j+3];
                    }
                }

            }
            
        }
            System.out.println(fraseCripto);
    }
}