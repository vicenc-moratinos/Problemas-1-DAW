public class Cadenas9Repaso {

    public static void main (String[]args) {

        
        String cad1 = "Esto es una String";
        String cad2 = "Esto tambien";
        String cad3 = "";
        String cad4 = "";
        
        System.out.println("cad1 = cad2: " + cad1.equals(cad2));
        
        cad3 = cad1.concat(cad2);
        System.out.println("cad1 + cad2: " + cad3);

        cad4 = cad1.concat(cad2);

        System.out.println("cad3 = cad4: "+ cad3.equals(cad4));

        System.out.println("cad1 = "+ cad1.length() + " cad2 = "+cad2.length());

        cad3 = cad1;
        cad1 = cad2;
        cad2 = cad3;

        System.out.println("cad1 = "+cad1 + " cad2 = " + cad2);

        cad1 = cad1.replace("tambien","ademas");
        System.out.println("cad1 = "+cad1);

    }
}