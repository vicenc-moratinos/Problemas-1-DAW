import java.util.regex.*;
import java.util.Scanner;

public class Expresiones7 {

    public static void main (String[]args) {

        Scanner sc = new Scanner(System.in);
        String fecha = "";

        Pattern p = Pattern.compile("^(0[1-9]|[1-2][0-9]|3[0-1])/(0[1-9]|1[0-2])/[0-9]{4}$");
        Matcher m;

        do {

            System.out.print("Introduce una fecha 'dd/mm/aa': ");
            fecha = sc.nextLine();
            m = p.matcher(fecha);

            if (m.matches()) {
                System.out.println("La fecha " + fecha + " es correcta ");
            }
            else {
                System.out.println("no es correcto");
            }
        }
        while (!m.matches());
    }
}