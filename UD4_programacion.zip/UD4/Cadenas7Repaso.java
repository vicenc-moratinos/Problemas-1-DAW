import java.util.Scanner;

public class Cadenas7Repaso {

    public static void main (String[]args) {

        Scanner sc = new Scanner(System.in);
        String cad ="";
        String cadenaFinal ="";
        int longitud;
        int i = 0;
        char letra = '_';
        char ultimaLetra = '_';

        System.out.println("CAd1");
        cad = sc.nextLine();
        
        cad = cad.toLowerCase();

        longitud = cad.length();
        for (i = 0; i < longitud; i++)
        {
            letra = cad.charAt(i);

            if (i == 0 || ultimaLetra == ' ')
            {
                letra = Character.toUpperCase(letra);
            }
            else
            {
                letra = cad.charAt(i);
            }
            cadenaFinal += letra;
            ultimaLetra = letra;

        }
        System.out.println(cadenaFinal);
    }
}