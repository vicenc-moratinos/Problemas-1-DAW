import java.util.Scanner;
import java.util.Arrays;

public class Arrays6 {
    public static void main (String[]args){

        String numeroCambiar = "";
        String nuevoNumero = "";
        String arrayToString;
        int [] arrayDeNumeros = new int [100];
        Scanner sc = new Scanner(System.in);

        for (int i = 0; i < arrayDeNumeros.length ; i++){
            arrayDeNumeros[i] = (int)(Math.random()*(101));
        }

        System.out.println("Introcude el numero a cambiar");
        numeroCambiar = sc.nextLine();
        System.out.println("Introduce el numero nuevo");
        nuevoNumero = sc.nextLine();

        nuevoNumero = "\"" +  nuevoNumero + "\",";
        numeroCambiar = " " + numeroCambiar + ",";
        arrayToString = Arrays.toString(arrayDeNumeros);
        
        arrayToString = arrayToString.replace(numeroCambiar,nuevoNumero);
        System.out.println(arrayToString);
    }
}