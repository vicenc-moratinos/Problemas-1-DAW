import java.util.Scanner;
import java.util.regex.*;

public class ExpresionesRegulares6 {

    public static void main (String[]args) {

        //Programa para validar un correo

        Scanner sc = new Scanner(System.in);
        String correo = "";
        Pattern patronCorreo = Pattern.compile("^[a-z0-9_-]([a-z0-9\\._-]*[a-z0-9_-])@([a-z0-9]([a-z0-9-]*[a-z0-9])\\.){1,}[a-z]{2,3}$");
        Matcher matcherCorreo;

        try {
                

            do {
                
                System.out.print("Intoroduce tu correo 'correo@dominio.com' o introduce 's' para salir: ");
                correo = sc.nextLine().toLowerCase();

                matcherCorreo = patronCorreo.matcher(correo);
                
                if (matcherCorreo.matches()) {
                    System.out.println("Tu correo "+ correo + " es válido");
                }

                else if (!correo.equals("s")) {
                    System.out.println("Tu correo no es válido");
                }
            }
            while (!correo.equals("s"));
        }
        catch (Exception e) {
            System.out.println("excepcion");
        }
    }   
}