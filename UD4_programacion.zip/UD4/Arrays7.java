import java.util.Scanner;
import java.util.Arrays;

public class Arrays7 {

enum Meses {
    ENERO, FEBRERO, MARZO, ABRIL, MAYO, JUNIO,
    JULIO, AGOSTO, SEPTIEMBRE, NOVIEMBRE, DICIEMBRE
}
    public static void main (String[]args){
        
        Scanner sc = new Scanner(System.in);
        int [] temperaturaMedia = new int[12];

        for(int i = 0; i < Meses.values().length;i++){
            System.out.println("Introduce la º media del mes de " + Meses.values()[i]);
            temperaturaMedia[i] = sc.nextInt();
        } 

        for (int i = 0; i < temperaturaMedia.length -1 ;i++) {
            System.out.println(Meses.values()[i] + ": ");
                for(int j = 0; j < temperaturaMedia[i] ; j++) {
                    if (j % 3 == 0) {
                        System.out.print("*");
                    }
                }
        }
    }
}
