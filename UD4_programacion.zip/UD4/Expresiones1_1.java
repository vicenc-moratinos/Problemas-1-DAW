import java.util.regex.*;
import java.util.Scanner;

public class Expresiones1_1 {

    public static void main (String[]args) {

        Scanner sc = new Scanner(System.in);
        String opcionMenu = "";
        String carnet = "";
        String carnetNie = "";
        char letraCarnet = ' ';
        String letrasSegunRestoDni = "TRWAGMYFPDXBNJZSQVHLCKE";
        String letrasSegunRestoNie = "XYZ";
        int numerosCarnet = 0;
        int resto = 0;

        Matcher comprobacionPatronDni = null;
        Matcher comprobacionPatronNie = null;

        do {
            System.out.print("Introduce 'NIE' , 'DNI' o 'S' para salir: ");
            opcionMenu = sc.nextLine().toUpperCase();

            switch (opcionMenu) {
                case "DNI":
                    do {

                        try{

                            System.out.print("Introduce tu DNI con formato '12345678X': ");
                            carnet = sc.nextLine().toUpperCase();
                            
                            Pattern patronDni = Pattern.compile("^[0-9]{8}[A-Z]{1}$");
                            comprobacionPatronDni = patronDni.matcher(carnet);

                            if (!comprobacionPatronDni.matches()) {
                                System.out.print("no coincide el formato\n");
                            }
                            else {
                                numerosCarnet = Integer.parseInt(carnet.substring(0,8));
                                letraCarnet = carnet.charAt(8);
                                resto = numerosCarnet % 23;
                                if (letrasSegunRestoDni.charAt(resto) != letraCarnet) {
                                    System.out.print("La letra no es correcta\n");
                                }
                                else {
                                    System.out.println("Tu DNI válido es: " + carnet);
                                }
                            }
                        }
                        catch (Exception e) {
                            System.out.println("Hubo una excepcion");
                        }
                    }
                    while (!comprobacionPatronDni.matches() || letrasSegunRestoDni.charAt(resto) != letraCarnet);
                break;

            case "NIE":
                do {

                    try{

                        System.out.print("Introduce tu NIE con formato 'X1234567X': ");
                        carnet = sc.nextLine().toUpperCase();
                        
                        Pattern patronNie = Pattern.compile("^[XYZ]{1}[0-9]{7}[A-Z]{1}$");
                        comprobacionPatronNie = patronNie.matcher(carnet);

                        if (!comprobacionPatronNie.matches()) {
                            System.out.print("no coincide el formato\n");
                        }
                        else {

                            letraCarnet = carnet.charAt(0);
                            carnetNie = letrasSegunRestoNie.indexOf(letraCarnet);
                            carnetNie += carnet.substring(1,8);
                            numerosCarnet = Integer.parseInt(carnetNie.substring(0,8));
                            letraCarnet = carnet.charAt(8);
                            resto = numerosCarnet % 23;
                            if (letrasSegunRestoDni.charAt(resto) != letraCarnet) {
                                System.out.print("La letra no es correcta\n");
                            }
                            else {
                                System.out.println("Tu NIE válido es: " + carnet);
                            }
                        }
                    }
                    catch (Exception e) {
                        System.out.println("Hubo una excepcion");
                    }
                }
                while (!comprobacionPatronNie.matches() || letrasSegunRestoDni.charAt(resto) != letraCarnet);

                break;

            default:
                System.out.println("Introduce una opcion correcta");
            }
        }
        while (!opcionMenu.equals("S"));
        
    }
}