import java.util.Scanner;

public class Cadenas8Repaso {

    public static void main (String[]args) {

        Scanner sc = new Scanner(System.in);
        
        String cad;
        char letra = '_';
        String vocales ="aeiou";
        String numeros = "1234567890";
        String consonantes = "qwertyuiopñlkjhgfdsazxcvbnmçñ";
        int vocalesC =0;
        int consonantesC =0;
        int numerosC=0;
        int otros=0;
        int longitud = 0;
        int i = 0;

        System.out.println("cad");
        cad = sc.nextLine();
        longitud = cad.length();

        for (i = 0; i < longitud; i++)
        {
            letra = cad.charAt(i);
            String letraString = String.valueOf(letra);

            if (vocales.contains(letraString))
            {
                vocalesC++;
            }

            else if (numeros.contains(letraString))
            {
                numerosC++;
            }
            else if (consonantes.contains(letraString))
            {
                consonantesC++;
            }
            else 
            {
                otros++;
            }
        }
        System.out.println("vocales: "+ vocalesC);
        System.out.println("consonantes: "+consonantesC);
        System.out.println("numeros: "+numerosC);
        System.out.println("otros: "+otros);
        
    }
}