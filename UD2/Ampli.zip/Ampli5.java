import java.util.Scanner;

public class Ampli5 {

    public static void main (String[]args){

        Scanner sc = new Scanner(System.in);
        char a, b,c,d,e;
        
        System.out.println("A");
        a = sc.nextLine().charAt(0);
        System.out.println("b");
        b = sc.nextLine().charAt(0);
        System.out.println("c");
        c = sc.nextLine().charAt(0);
        System.out.println("d");
        d = sc.nextLine().charAt(0);
        System.out.println("e");
        e = sc.nextLine().charAt(0);

        String palabra = ""+a+b+c+d+e;
        System.out.println(palabra);
    }
}