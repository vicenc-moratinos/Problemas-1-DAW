import java.util.Scanner;

public class Ampli3 {

    public static void main (String[]args){

        Scanner sc = new Scanner(System.in);
        //String palabra;
        int num = 10;
        char letra;

        System.out.println("Introduce una letra");
        letra = sc.nextLine().charAt(0);
        //System.out.println("Introduce una palabra");
        //palabra = sc.nextLine();

        //palabra = letra + palabra;
        letra += num;
        
        System.out.println(letra);
    }
    
}
