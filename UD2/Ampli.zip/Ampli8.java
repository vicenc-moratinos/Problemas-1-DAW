public class Ampli8 {

    static double PII = Math.PI;

    public static void main (String[]args){
        double rad = 5;
        double perimetro = (PII *2)*rad;
        System.out.printf("\nEl perimetro es %.3f\n",perimetro);
    }
}