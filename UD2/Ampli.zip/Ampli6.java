public class Ampli6 {

    public static void main (String[]args){

        String a = "ho";
        String b = "la";
        String ab ="";
        ab = ab.concat(a);
        ab = ab.concat(b);
        System.out.println(ab);

    }


}