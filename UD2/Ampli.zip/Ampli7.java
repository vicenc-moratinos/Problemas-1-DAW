public class Ampli7 {

    public static void main (String[]args){

        String a = "ho";
        String b = "la";
        String c = "";
        c = a;
        a = b;
        b = c;
        System.out.println("a = "+a + " b = "+b);
    }
}