public class Ampli10 {

    public enum Coches {
        ferrari, fiat, susuki, pussywaggon
    }

    public static void main  (String[]args){
        
        boolean tru;
        Coches var1 = Coches.ferrari;
        Coches var2 = Coches.pussywaggon;

        tru = var1.equals(var2);
        System.out.println(tru);
        System.out.println(var1.ordinal()>var2.ordinal()?(var1+"es primero"):(var1+"es segundo"));
        

    }

}