import java.util.Scanner;

public class Ampli9 {

    public static void main (String[]args){
        System.out.println("pon tu edad parse");
        Scanner sc = new Scanner(System.in);
        int edad;
        edad = Integer.parseInt(sc.nextLine());
        System.out.println((edad >= 18)? "maot":"menut");



    }
}