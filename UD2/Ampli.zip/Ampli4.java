import java.util.Scanner;
public class Ampli4 {
    public static void main(String []args){

        int dni;
        char genero;
        String nombre;
        double estatura;

        Scanner sc = new Scanner(System.in);

        System.out.println("Nombre");
        nombre = sc.nextLine();
        System.out.println("Dni");
        dni = Integer.parseInt(sc.nextLine());
        System.out.println("Estatura");
        estatura = Double.parseDouble(sc.nextLine());
        System.out.println("Genero");  
        genero = sc.nextLine().charAt(0);

        System.out.printf("\n Nombre: %s\n DNI: %d\n Estatura %.3f\n Genero %c",nombre,dni,estatura,genero);

        

        


    }
}