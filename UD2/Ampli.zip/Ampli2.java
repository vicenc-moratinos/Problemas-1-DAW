import java.util.Scanner;

public class Ampli2 {
    
    public static void main (String[]args) {

        Scanner sc = new Scanner(System.in);
        int a;
        int b;
        boolean comprobacion;
        System.out.println("Introduce a:");
        a = sc.nextInt();
        System.out.println("Introduce b:");
        b = sc.nextInt();
        comprobacion = a == b;
        System.out.printf("\n%d es igual a %d: %b",a,b,comprobacion);
        comprobacion = a != b;
        System.out.printf("\n%d es distinto a %d: %b",a,b,comprobacion);
        comprobacion = a < b;
        System.out.printf("\n%d es menor a %d: %b",a,b,comprobacion);
        comprobacion = a > b;
        System.out.printf("\n%d es mayor a %d: %b",a,b,comprobacion);
        comprobacion = a <= b;
        System.out.printf("\n%d es menor o igual a %d: %b",a,b,comprobacion);
        comprobacion = a >= b;
        System.out.printf("\n%d es mayor o igual a %d: %b",a,b,comprobacion);


    }

}
